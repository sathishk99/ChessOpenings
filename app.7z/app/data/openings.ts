import { Opening } from '../types/chess';

export const openings: Opening[] = [
  {
    id: 'queens-gambit',
    name: "Queen's Gambit",
    eco: 'D06',
    description: "One of the oldest known chess openings. White offers a pawn to gain control of the center.",
    moves: [
      {
        san: 'd4',
        comment: 'White controls the center with the queen pawn',
        fen: 'rnbqkbnr/pppppppp/8/8/3P4/8/PPP1PPPP/RNBQKBNR b KQkq d3 0 1'
      },
      {
        san: 'd5',
        comment: 'Black mirrors, also controlling the center',
        fen: 'rnbqkbnr/ppp1pppp/8/3p4/3P4/8/PPP1PPPP/RNBQKBNR w KQkq d6 0 2'
      },
      {
        san: 'c4',
        comment: 'The Queen\'s Gambit! White offers the c-pawn to disrupt Black\'s center',
        fen: 'rnbqkbnr/ppp1pppp/8/3p4/2PP4/8/PP2PPPP/RNBQKBNR b KQkq c3 0 2'
      }
    ]
  }
];