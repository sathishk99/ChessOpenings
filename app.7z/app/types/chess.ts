export interface Move {
    san: string;
    comment?: string;
    fen: string;
  }
  
  export interface Opening {
    id: string;
    name: string;
    eco: string;
    moves: Move[];
    description: string;
  }