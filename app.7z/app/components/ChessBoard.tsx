'use client';

import { Chessboard } from 'react-chessboard';
import { Chess } from 'chess.js';
import { useState, useEffect } from 'react';
// Assuming these types are defined elsewhere and correctly imported
// For this example, I'll define simple placeholder types if they are not provided
interface Move {
  san: string;
}

interface Opening {
  name: string;
  eco: string;
  description: string;
  moves: Move[];
}

interface ChessBoardProps {
  opening: Opening;
}

export default function ChessBoardComponent({ opening }: ChessBoardProps) {
  // Initialize Chess.js game instance
  const [game, setGame] = useState(new Chess());
  // State to track the current move index in the opening sequence
  const [currentMoveIndex, setCurrentMoveIndex] = useState(-1);
  // State to hold the current FEN position for the chessboard
  const [position, setPosition] = useState(game.fen());

  // Effect to reset the board when a new opening is selected
  useEffect(() => {
    const newGame = new Chess();
    setGame(newGame);
    setPosition(newGame.fen());
    setCurrentMoveIndex(-1); // Reset move index
  }, [opening]);

  /**
   * Plays moves up to a specified index in the opening sequence.
   * @param moveIndex The index of the last move to play.
   */
  const playMove = (moveIndex: number) => {
    const newGame = new Chess(); // Create a new game instance
    
    // Play moves up to the selected index
    for (let i = 0; i <= moveIndex; i++) {
      // Ensure the move exists before attempting to play it
      if (opening.moves[i]) {
        newGame.move(opening.moves[i].san);
      }
    }
    
    setGame(newGame); // Update the game state
    setPosition(newGame.fen()); // Update the board position
    setCurrentMoveIndex(moveIndex); // Update the current move index
  };

  /**
   * Resets the chessboard to the initial position.
   */
  const resetBoard = () => {
    const newGame = new Chess(); // Create a fresh game instance
    setGame(newGame);
    setPosition(newGame.fen());
    setCurrentMoveIndex(-1); // Reset move index to indicate no moves played
  };

  /**
   * Advances the board to the next move in the opening sequence.
   */
  const nextMove = () => {
    // Check if there are more moves to play
    if (currentMoveIndex < opening.moves.length - 1) {
      playMove(currentMoveIndex + 1);
    }
  };

  /**
   * Reverts the board to the previous move in the opening sequence.
   */
  const prevMove = () => {
    // Check if there are previous moves to revert to
    if (currentMoveIndex > -1) { // Changed from currentMoveIndex >= 0 to avoid playing move -1
      playMove(currentMoveIndex - 1);
    }
  };

  // Options object for the Chessboard component
  const chessboardOptions = {
    position: position, // The current FEN string
    // arePiecesDraggable: true, // This prop is not directly available on Chessboard, handled by onPieceDrop
    // boardWidth: 384, // This is usually controlled by parent div's width or CSS
    id: 'chess-board', // A unique ID for the chessboard
    // You can add other options here if needed, like orientation, onPieceDrop, etc.
  };

  return (
    <div className="flex flex-col items-center space-y-4 p-4 bg-gray-100 rounded-lg shadow-lg">
      <h1 className="text-2xl font-bold text-gray-800">Chess Opening Explorer</h1>
      <div className="w-full max-w-sm aspect-square"> {/* Use aspect-square for responsive square board */}
         <Chessboard options={chessboardOptions} />
      </div>
      
      <div className="flex space-x-4 mt-4">
        <button
          onClick={resetBoard}
          className="px-6 py-3 bg-gray-600 text-white font-semibold rounded-lg shadow-md hover:bg-gray-700 transition duration-300 ease-in-out"
        >
          Reset
        </button>
        <button
          onClick={prevMove}
          disabled={currentMoveIndex <= -1} // Disable if at start or before first move
          className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-300 ease-in-out disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          Previous
        </button>
        <button
          onClick={nextMove}
          disabled={currentMoveIndex >= opening.moves.length - 1} // Disable if at last move
          className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-300 ease-in-out disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          Next
        </button>
      </div>
      
      <div className="text-center mt-4 p-4 bg-white rounded-lg shadow-inner w-full max-w-md">
        <p className="text-xl font-bold text-gray-900">{opening.name}</p>
        <p className="text-base text-gray-700 mt-1">ECO: {opening.eco}</p>
        <p className="text-sm text-gray-600 mt-2 leading-relaxed">{opening.description}</p>
        {/* Display current move number if applicable */}
        {currentMoveIndex > -1 && opening.moves[currentMoveIndex] && (
          <p className="text-sm text-gray-500 mt-2">
            Current Move: {currentMoveIndex + 1}. {opening.moves[currentMoveIndex].san}
          </p>
        )}
      </div>
    </div>
  );
}
