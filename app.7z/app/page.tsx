'use client';

import { useState } from 'react';
import ChessBoardComponent from './components/ChessBoard';
import OpeningsList from './components/OpeningsList';
import MovesList from './components/MovesList';
import { openings } from './data/openings';

export default function Home() {
  const [selectedOpening, setSelectedOpening] = useState(openings[0]);
  const [currentMoveIndex, setCurrentMoveIndex] = useState(-1);

  const handleMoveClick = (index: number) => {
    setCurrentMoveIndex(index);
  };

  const handleOpeningSelect = (opening: typeof openings[0]) => {
    setSelectedOpening(opening);
    setCurrentMoveIndex(-1);
  };

  return (
    <main className="min-h-screen bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-8">Chess Openings Explorer</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <OpeningsList
              openings={openings}
              selectedOpening={selectedOpening}
              onOpeningSelect={handleOpeningSelect}
            />
          </div>
          
          <div className="lg:col-span-1 flex justify-center">
            <ChessBoardComponent opening={selectedOpening} />
          </div>
          
          <div className="lg:col-span-1">
            <MovesList
              opening={selectedOpening}
              currentMoveIndex={currentMoveIndex}
              onMoveClick={handleMoveClick}
            />
          </div>
        </div>
      </div>
    </main>
  );
}